package com.example.bmiapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class PesoInferior : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_peso_inferior)

    }
}
